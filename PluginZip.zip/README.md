# Minimal Clozes
This snippet modifies the appearance of clozes to look more minimalistic.

## Preview
### Light Mode
![Preview1](https://raw.githubusercontent.com/anishaaa1/Minimal-Clozes/main/src/media/minimal-clozes-light.gif)
### Dark Mode
![Preview2](https://raw.githubusercontent.com/anishaaa1/Minimal-Clozes/main/src/media/minimal-clozes-dark.gif)